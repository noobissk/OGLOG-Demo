#pragma once
#define GLM_ENABLE_EXPERIMENTAL
#include <glm_math.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb_image.h>
#include <service/shader_manager.h>
