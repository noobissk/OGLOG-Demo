#pragma once
#include <logic/systems/system.h>
#include <logic/system_manager.h>
#include <logic/systems/transform_system.h>
#include <logic/systems/renderer_system.h>
#include <logic/systems/canvas_system.h>